class ColorHSV(object):
	def __init__(self, hue, saturation, value):
		self.hue = hue
		self.saturation = saturation
		self.value = value

class ColorHSVOps(object):
	def __init__(self):
		pass

ColorHSVOps = ColorHSVOps