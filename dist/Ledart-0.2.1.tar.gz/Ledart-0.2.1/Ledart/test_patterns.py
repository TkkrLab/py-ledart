from runPatternJob import find_patterns_in_dir
from matrix import matrix_size


def test():
    patterns = find_patterns_in_dir('patterns')
    assert(len(patterns) != 0)
    for pattern in patterns:
        pat = pattern()
        pat.generate()
        assert(len(pat) == matrix_size)
