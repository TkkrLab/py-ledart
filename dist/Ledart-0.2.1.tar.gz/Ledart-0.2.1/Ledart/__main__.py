import runPatternJob

if __name__ == "__main__":
    runPatternJob.main()