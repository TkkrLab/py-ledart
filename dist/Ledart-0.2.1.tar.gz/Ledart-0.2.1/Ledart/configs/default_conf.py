# import all patterns availble for use.
from Patterns.Patterns import *

localhost = "localhost"
ledboard = "ledboard"
dest = localhost

TARGETS = {
    dest: PixelLife(),
}
