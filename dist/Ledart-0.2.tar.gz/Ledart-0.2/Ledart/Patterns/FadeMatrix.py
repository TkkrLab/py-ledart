# pattern with fading pixels
